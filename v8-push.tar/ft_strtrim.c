/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tessaadi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/14 19:14:44 by tessaadi          #+#    #+#             */
/*   Updated: 2025/10/22 11:57:58 by ubuntu           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int ft_contain(char const c, char const *set)
{
    size_t i;

    i = 0;
    while (set[i])
    {
        if (c == set[i])
            return 1;
        i++;
    }
    return 0;
}

static void ft_strtrim_logic(char const *s1, char *str, int start, int end)
{
    int j;

    j = 0;
    while (start <= end)
    {
        str[j] = s1[start];
	j++;
	start++;
    }
    str[j] = '\0';
}

char *ft_strtrim(char const *s1, char const *set)
{
    int len;
    int k;
    char *str;

    if (s1 == NULL)
        return NULL;
    if (set == NULL || set[0] == '\0')
        return ft_strdup(s1);
    if (s1[0] == '\0')
        return ft_strdup("");

    len = ft_strlen(s1) - 1;
    while (len >= 0 && ft_contain(s1[len], set) == 1)
        len--;

    k = 0;
    while (s1[k] && ft_contain(s1[k], set) == 1)
        k++;

    if (k > len)
        return ft_strdup("");

    str = (char *)malloc(len - k + 2);
    if (str == NULL)
        return NULL;

    ft_strtrim_logic(s1, str, k, len);
    return str;
}

